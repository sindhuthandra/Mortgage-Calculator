﻿//****************************new form*****************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mortgage_Calculator
{
    public partial class New_form : Form
    {
        public New_form()
        {
            InitializeComponent();
        }

        //navigates to main form from new form
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            //hides the previous window
            this.Hide();
            //creating an object to the main form
            Main M = new Main();
            //displays the current window
            M.Show();
        }

        //navigates to open form from new form
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
           // this.Hide();
           Open_form OM = new Open_form();
            OM.Show();
        }

        //navigates to extra principle form from new form
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // this.Hide();
            ExtraPrinciple EM = new ExtraPrinciple();
            EM.Show();
        }

        //this closes the current window
        private void exitToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //navigates to help form from new form
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            // this.Hide();
            Help HM = new Help();
            HM.Show();
        }

        //navigates to about form from new form
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // this.Hide();
            About AM = new About();
            AM.Show();
        }
    }
}
